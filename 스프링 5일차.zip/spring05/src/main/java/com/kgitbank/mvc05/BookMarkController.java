package com.kgitbank.mvc05;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class BookMarkController {
	
	@Autowired
	BookMarkDAO dao;
	
	@RequestMapping("insert")
	public void insert(BookMarkDTO dto) throws Exception {
		System.out.println(dto.getId());
		System.out.println(dto.getName());
		System.out.println(dto.getSite());
		dao.insert(dto);
	} 
}
