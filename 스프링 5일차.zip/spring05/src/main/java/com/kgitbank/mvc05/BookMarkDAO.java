package com.kgitbank.mvc05;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;

public class BookMarkDAO {

	@Autowired
	SqlSessionTemplate my; //mybatis
	
	public void insert(BookMarkDTO dto) throws Exception {
		my.insert("book.insert",dto);
		
	}
}
